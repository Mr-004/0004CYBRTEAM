#!/usr/bin/python

import time
class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
print ("saat lu berdua sama cewe lu di tempat sepi")
print ("apa yang akan lu lakuin?")
 
print"+-------------------+"
print"+1. Ngajak Ngaji    +"
print"+                   +"
print"+2. di eue :v       +"
print"+                   +"
print"+-------------------+"
num1 = raw_input("pilih mhank : ")
if num1 == "1":
    print"Semoga Masuk Surga:) "
elif num1 == "2":
    print"Otak Bokep Njing:v"
else:
    print"kuy gelud tod:*"


while True:
 print bcolors.WARNING + ("Tobat Lah Nak Kiamat Udah dekat:)") + bcolors.ENDC

